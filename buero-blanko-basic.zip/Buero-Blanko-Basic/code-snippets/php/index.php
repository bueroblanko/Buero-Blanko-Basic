<?php

// silence is gold