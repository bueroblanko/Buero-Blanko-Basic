1. do the changes (add or remove snippets)
2. change the version on the code-sync-plugin.php file to a newer one ex: 0.0.01
3. add , commit and push 
4. create a new release on github https://github.com/[your-username]/[repo]/releases/new
5. create a tag and name it the same as your version
5. publish the release
6. done